"""
pyyhtml.

A simple HTML pseudo for Python.
"""
__version__ = "0.0.8"
__author__ = "Yusuf Emre Samur"



from .components import *
from .content import *
from .fileio import write_list_to_file